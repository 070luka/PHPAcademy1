<?php

/**
 * include, 
 * include_once,
 * require, 
 * require_once
 */

include '06-include/include-me-1.php';

//require_once 'functions.php';
//require_once 'functions.php';

/**
 * @notes:
 * where is this file found? path is relative to what?
 * __DIR__, __FILE__, ..
 * 
 * mention why we don't close php code on end of file
 *
 */

//$config = include('06-include/config.php');



