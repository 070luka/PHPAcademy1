PHP Manual:  
http://php.net/manual/en/index.php
  
http://php.net/manual/en/book.strings.php  
http://php.net/manual/en/book.array.php  
..

W3Schools PHP 5 Tutorial:  
http://www.w3schools.com/php/default.asp  

Codecademy:  
http://www.codecademy.com/tracks/php  

PHP The Right Way:  
http://www.phptherightway.com/  

Tuts+:  
https://code.tutsplus.com/courses/php-fundamentals

Codewars:  
https://www.codewars.com/?language=php
