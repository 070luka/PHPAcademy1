<?php

echo "Included file 1";

//require 'include-me-2.php';