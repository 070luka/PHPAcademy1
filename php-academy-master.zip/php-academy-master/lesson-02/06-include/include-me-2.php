<?php

echo "Included file 2";