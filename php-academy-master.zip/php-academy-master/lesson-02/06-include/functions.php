<?php

function escape()
{

}

function todays_date()
{

}




