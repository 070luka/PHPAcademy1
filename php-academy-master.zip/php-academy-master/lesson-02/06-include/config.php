<?php

return [
    'db_user'   => 'root',
    'db_pass'   => 'lol123',
    'url'       =>  '',
    //..
];