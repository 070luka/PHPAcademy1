<?php

/**
 * Show me how my PHP is configured
 */

phpinfo();

xyz(); //should trigger error at the bottom