<?php

echo 'I am index.php !! I am entry point here, nothing runs besides me :]';

//var_dump($_SERVER['REQUEST_URI']);
