<?php

/**
 * example config file
 */
return [
    'some_config_key' => 'some config value',
    'mode'  => 'development',
    'app_url' => 'http://localhost/lesson-04/mvc-app/',
];