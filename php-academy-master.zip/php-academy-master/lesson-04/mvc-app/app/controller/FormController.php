<?php

class FormController
{
    /**
     * Registration page with form
     */
    public function index()
    {
        //@todo
    }

    /**
     * Form submit
     */
    public function submit()
    {
        //@todo
    }

    /**
     * Thank you page
     */
    public function thankyou()
    {
        //@todo
    }

}