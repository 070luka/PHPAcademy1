<?php

namespace Ferit;

class Student
{

}