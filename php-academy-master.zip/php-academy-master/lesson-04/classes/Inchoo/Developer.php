<?php

namespace Inchoo;

class Developer
{

    

}