<?php

/**
 * example config file
 */
return [
    //'some_config_key' => 'some config value',
    'url' => 'http://test.loc/lesson-05/mvc-app/',
    'mode'  => 'development',
    'admin_email' => 'student@etf.hr',
    'admin_password' => 'phpakademija',

];