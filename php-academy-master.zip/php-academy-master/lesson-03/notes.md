
forms and validation
* html5 frontend validation - types, required, pattern, ..  
  https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/Forms/Data_form_validation
  http://www.w3schools.com/html/html_form_attributes.asp

* backend filters  
  http://php.net/manual/en/filter.examples.validation.php
  http://www.w3schools.com/php/php_filter.asp

session, login
* remember me - session time   
  http://php.net/manual/en/function.session-set-cookie-params.php
* promijeniti gdje je session sacuvan  
  http://php.net/manual/en/function.session-save-path.php

example app
* forma za prijavu na php akademiju, srediti formu
* naslovnica, forma, success page
* prijave se pisu u fajl

zadaca
* zavrsiti formu i pisanje podataka u fajl
* "Uploadaj primjer svog koda" - upload fajla na server ($_FILES superglobal)
* ukrasiti page/formu css-om (opcionalno); bootstrap:
  http://getbootstrap.com/
* admin vidi sve prijave uz autentikaciju (opcionalno)


