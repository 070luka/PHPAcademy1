<html>
    <body>

    <h1>$_SERVER</h1>
    <pre><?php

        var_dump($_SERVER);

    ?></pre>
    </body>
</html>
